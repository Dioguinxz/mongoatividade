package com.example.mongoDBShow.repository;

import com.example.mongoDBShow.entity.Show;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ShowRepository extends MongoRepository<Show, String>{

}