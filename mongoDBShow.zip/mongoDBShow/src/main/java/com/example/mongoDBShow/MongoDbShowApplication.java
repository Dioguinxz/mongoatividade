package com.example.mongoDBShow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MongoDbShowApplication {

	public static void main(String[] args) {
		SpringApplication.run(MongoDbShowApplication.class, args);
	}


}
