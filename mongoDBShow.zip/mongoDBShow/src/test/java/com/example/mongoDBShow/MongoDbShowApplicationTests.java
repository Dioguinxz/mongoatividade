package com.example.mongoDBShow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongoDbShowApplicationTests {

	@Test
	void contextLoads() {
	}

}
